<?php

/*
Plugin Name: Uipro Extensions
Plugin URI: http://www.uipro.net/
Description: This plugin is developed to enhance capabilities of Trendy WordPress Theme and to provide some advanced features.
Author: Uipro
Version: 1.0.0
Author URI: http://uipro.net/
License: Themeforest Standard Licenses
License URI: http://themeforest.net/licenses/standard
*/

/*
NOTE(s):
1. This plugin is specifically developed, to be used with UX Creative WordPress Theme, by Uipro.
2. This plugin automatically activates with theme installation.
*/



    // Load theme options
    if ( file_exists( dirname( __FILE__ ) . '/uipro_theme_options/admin-init.php' ) ) {
        require_once dirname( __FILE__ ) . '/uipro_theme_options/admin-init.php';
    }
	
    // Load custom widgets
    if ( file_exists( dirname( __FILE__ ) . '/uipro_widgets/uipro_widgets_index.php' ) ) {
        require_once dirname( __FILE__ ) . '/uipro_widgets/uipro_widgets_index.php';
    }


?>