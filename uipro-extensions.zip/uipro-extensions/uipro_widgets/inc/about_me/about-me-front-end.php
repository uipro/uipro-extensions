<?php	
	echo $before_widget;	
	echo $before_title . $about_title . $after_title;
?>
<div class="about-me">
<p class="my-thumb">
	<a href="<?php echo esc_url( $about_profile ); ?>" title="<?php echo esc_html__( 'Author', 'trendy-by-uipro' ); ?>">
		<img src="<?php echo esc_url( $about_img_url ); ?>" alt="<?php echo esc_html__( 'Author', 'trendy-by-uipro' ); ?>">
	</a>
</p>
<p><?php echo $about_intro; ?></p>
<p class="signature"><img src="<?php echo esc_url( $about_signature ); ?>" alt="<?php echo esc_html__( 'signature', 'trendy-by-uipro' ); ?>"></p>
</div>
<?php echo $after_widget; ?>


