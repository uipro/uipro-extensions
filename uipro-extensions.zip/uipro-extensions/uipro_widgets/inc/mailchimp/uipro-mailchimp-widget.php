<p>
	<label>Title</label>
	<input class="widefat" name="<?php echo $this->get_field_name('mailchimp_title'); ?>" type="text" value="<?php echo $mailchimp_title; ?>">
</p>
<p>
	<label>Sub Title</label>
	<input class="widefat" name="<?php echo $this->get_field_name('mailchimp_sub_title'); ?>" type="text" value="<?php echo $mailchimp_sub_title; ?>">
</p>
<p>
	<label>Form Action URL</label>
	<input class="widefat" name="<?php echo $this->get_field_name('mailchimp_form_url'); ?>" type="text" value="<?php echo $mailchimp_form_url; ?>">
	<br /><small><a href="http://kb.mailchimp.com/lists/signup-forms/host-your-own-signup-forms" title="How to get mailchimp form action url?" target="_blank">How to get mailchimp form action url?</a></small>
</p>