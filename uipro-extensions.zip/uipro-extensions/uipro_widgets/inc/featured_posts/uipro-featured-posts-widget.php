<p>
	<label>Title</label>
	<input class="widefat" name="<?php echo $this->get_field_name('featured_title'); ?>" type="text" value="<?php echo $featured_title; ?>">
</p>
<p>
	<label>Featured Posts Count</label>
	<input class="widefat" name="<?php echo $this->get_field_name('featured_posts_count'); ?>" type="text" value="<?php echo $featured_posts_count; ?>">
</p>
<?php
$select_like = $select_comment = $select_recent = NULL;
if ( $filter_posts_by == '_post_like_count' ) {
	$select_like = 'checked';
} elseif ( $filter_posts_by == 'comment_count' ) {
	$select_comment = 'checked';
} else {
	$select_recent = 'checked';
}
?>
<h4 style="margin-bottom:0;">Filter Posts By</h4>
<p style="margin-top:5px;">
	<label><input type="radio" name="<?php echo $this->get_field_name('filter_posts_by'); ?>" value="_post_like_count" <?php echo $select_like; ?>> Most Liked</label><br />
	<label><input type="radio" name="<?php echo $this->get_field_name('filter_posts_by'); ?>" value="comment_count" <?php echo $select_comment; ?>> Most Commnented</label><br />
	<label><input type="radio" name="<?php echo $this->get_field_name('filter_posts_by'); ?>" value="recently_published" <?php echo $select_recent; ?>> Recently Published</label>
</p>
