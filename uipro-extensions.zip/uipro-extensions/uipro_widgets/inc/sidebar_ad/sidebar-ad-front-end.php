<div class="aside-widget ad-widget">
	<div class="widget-inner">
		<a class="banner-ad" href="<?php echo esc_url( $ad_link ); ?>" title="<?php echo esc_html__( 'sponsor', 'trendy-by-uipro' ); ?>"><img src="<?php echo esc_url( $ad_img_url ); ?>" alt="<?php echo esc_html__( 'sponsor', 'trendy-by-uipro' ); ?>"></a>
	</div>
</div>